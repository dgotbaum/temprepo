// Copyright (c) 2017-2019 Samuel Kahn (samuel@kahncode.com). All Rights Reserved.

using System;
using System.IO;
using UnrealBuildTool;

public class GitCentral : ModuleRules
{
	public GitCentral(ReadOnlyTargetRules Target)
        : base(Target)
    {
        Console.WriteLine("GitCentral.Build.cs: {0} {1} {2} {3}", Target.Name, Target.Type.ToString(), Target.Configuration.ToString(), Target.Platform.ToString());

        if (Target.Configuration == UnrealTargetConfiguration.DebugGame)
        {
            PublicDefinitions.Add("GITCENTRAL_ENABLE_DEBUG_LOG=1");
            bFasterWithoutUnity = true; //Compile without unity in debug to catch compilation errors
        }

        //RunUAT BuildPlugin always builds with NoSharedPCH and IWYU anyway
        PCHUsage = ModuleRules.PCHUsageMode.NoSharedPCHs;
        PrivatePCHHeaderFile = "Private/GitSourceControlPrivatePCH.h";
        bEnforceIWYU = true;

        PrivateDependencyModuleNames.AddRange(
			new string[] {
				"Core",
				"Slate",
				"SlateCore",
				"EditorStyle",
				"SourceControl",
				"InputCore",
                "UnrealEd",
                "CoreUObject",
                "Engine",
                "Json"
			}
		);
	}
}
